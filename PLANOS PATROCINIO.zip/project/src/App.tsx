import React from 'react';
import { Diamond, Award, Medal } from 'lucide-react';
import SponsorshipTier from './components/SponsorshipTier';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  const tiers = [
    {
      title: 'Prata',
      icon: <Medal className="w-8 h-8 text-gray-600" />,
      price: 'R$ 1.000,00',
      benefits: [
        'Visibilidade em todas as mídias sociais',
        'Logo no telão durante o evento',
        'Inclusão em materiais impressos',
        'Inclui 5 ingressos'
      ],
      color: 'from-gray-50 to-gray-100',
      buttonColor: 'bg-gray-600 hover:bg-gray-700',
      iconBg: 'bg-gray-100'
    },
    {
      title: 'Ouro',
      icon: <Award className="w-8 h-8 text-yellow-600" />,
      price: 'R$ 2.500,00',
      benefits: [
        'Visibilidade em todas as mídias sociais',
        'Stand interno durante o evento',
        'Vídeo de 30 segundos no telão',
        'Inclusão em materiais impressos',
        'Inclui 7 ingressos'
      ],
      color: 'from-yellow-50 to-yellow-100',
      buttonColor: 'bg-yellow-600 hover:bg-yellow-700',
      iconBg: 'bg-yellow-100',
      featured: true
    },
    {
      title: 'Diamante',
      icon: <Diamond className="w-8 h-8 text-blue-600" />,
      price: 'R$ 5.000,00',
      benefits: [
        'Visibilidade em todas as mídias sociais',
        'Exposição da marca interna e externa',
        'Vídeo institucional no telão (1 minuto)',
        'Inclusão em materiais impressos',
        'Inclui 12 ingressos'
      ],
      color: 'from-blue-50 to-blue-100',
      buttonColor: 'bg-blue-600 hover:bg-blue-700',
      iconBg: 'bg-blue-100'
    }
  ];

  const getWhatsAppLink = () => {
    const message = encodeURIComponent('Tenho dúvidas sobre qual plano escolher.');
    return `https://wa.me/5541995140918?text=${message}`;
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      <main className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Escolha seu Plano de Patrocínio
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Faça parte deste evento único e promova sua marca para um público engajado e diversificado
          </p>
        </div>

        <div className="flex flex-col items-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
            {tiers.map((tier, index) => (
              <SponsorshipTier
                key={tier.title}
                {...tier}
                delay={index * 150}
                pulseDelay={index}
              />
            ))}
          </div>

          <div className="mt-16 text-center">
            <p className="text-gray-600 mb-6">
              Tem dúvidas sobre qual plano escolher?
            </p>
            <a
              href={getWhatsAppLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-600 text-white hover:bg-green-700 transition-colors px-6 py-3 rounded-lg font-medium inline-flex items-center gap-2 hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
            >
              Fale com nossa equipe
            </a>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;