import React from 'react';

const Header = () => {
  return (
    <div className="bg-gradient-to-b from-green-600 to-green-700">
      <header className="relative py-16 px-4">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1544427920-c49ccfb85579?auto=format&fit=crop&q=80')] opacity-10 bg-cover bg-center mix-blend-overlay" />
        
        <div className="relative container mx-auto max-w-4xl text-center">
          <div className="mb-8 flex justify-center">
            <img 
              src="/logo.png"
              alt="ACINFAZ Jovem"
              className="h-32 md:h-40 object-contain"
            />
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight text-white">
            Evento Stand Up Circense
          </h1>
          
          <p className="text-xl md:text-2xl text-green-100">
            Cotas de Patrocínio - ACINFAZ JOVEM
          </p>
        </div>
      </header>
    </div>
  );
}

export default Header;