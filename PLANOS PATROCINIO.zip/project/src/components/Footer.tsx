import React from 'react';
import { Mail, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-green-600 text-white py-8 px-4">
      <div className="container mx-auto max-w-4xl text-center">
        <div className="flex flex-col md:flex-row items-center justify-center gap-6 mb-6">
          <a
            href="mailto:contato@acinfazjovem.com.br"
            className="flex items-center gap-2 hover:text-green-100 transition-colors"
          >
            <Mail className="w-5 h-5" />
            contato@acinfazjovem.com.br
          </a>
          <span className="hidden md:inline">|</span>
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            (41) 99999-9999
          </div>
        </div>
        
        <p className="text-green-100 text-sm">
          &copy; 2024 ACINFAZ JOVEM. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
}

export default Footer;