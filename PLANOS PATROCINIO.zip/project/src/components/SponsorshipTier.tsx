import React from 'react';
import { Check } from 'lucide-react';

interface SponsorshipTierProps {
  title: string;
  icon: React.ReactNode;
  price: string;
  benefits: string[];
  color: string;
  buttonColor: string;
  iconBg: string;
  featured?: boolean;
  delay: number;
  pulseDelay: number;
}

const SponsorshipTier: React.FC<SponsorshipTierProps> = ({
  title,
  icon,
  price,
  benefits,
  color,
  buttonColor,
  iconBg,
  featured = false,
  delay,
  pulseDelay
}) => {
  const getWhatsAppLink = (planTitle: string) => {
    const message = encodeURIComponent(
      `Olá! Tenho interesse no Plano ${planTitle} do evento Stand Up Circense. Gostaria de mais informações sobre esta cota de patrocínio.`
    );
    return `https://wa.me/5541999217821?text=${message}`;
  };

  return (
    <div
      className="relative group cursor-pointer"
      style={{
        animation: `fadeIn 0.6s ease-out ${delay}ms forwards`
      }}
    >
      <div
        className={`
          relative
          transform transition-all duration-300 ease-in-out
          group-hover:scale-[1.02]
          rounded-2xl p-8
          border border-gray-200
          h-full flex flex-col
          shadow-[0_0_20px_rgba(0,0,0,0.1)]
          group-hover:shadow-[0_0_25px_rgba(0,0,0,0.15)]
          overflow-visible
          bg-gradient-to-br ${color}
        `}
      >
        {featured && (
          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2">
            <span className="bg-yellow-600 text-white px-6 py-2 rounded-full text-sm font-semibold shadow-lg whitespace-nowrap">
              Mais Popular
            </span>
          </div>
        )}

        <div className="text-center mb-8">
          <div className={`inline-block p-3 rounded-full ${iconBg} shadow-md mb-4`}>
            {icon}
          </div>
          <h2 className="text-2xl font-bold mb-2 text-gray-900">{title}</h2>
          <p className="text-3xl font-bold text-gray-800">{price}</p>
        </div>

        <ul className="space-y-4 flex-grow">
          {benefits.map((benefit, index) => (
            <li key={index} className="flex items-start gap-3">
              <span className={`mt-1 ${iconBg} p-1 rounded-full`}>
                <Check className="w-4 h-4 text-gray-700" />
              </span>
              <span className="text-gray-700">{benefit}</span>
            </li>
          ))}
        </ul>

        <a
          href={getWhatsAppLink(title)}
          target="_blank"
          rel="noopener noreferrer"
          className={`
            mt-8 w-full py-3 px-6 rounded-lg font-semibold
            transition-all duration-200 text-center text-white
            ${buttonColor}
            transform hover:translate-y-[-2px]
            hover:shadow-lg
          `}
          style={{
            animation: `pulse 2s cubic-bezier(0.4, 0, 0.6, 1) ${pulseDelay}s infinite`
          }}
        >
          Selecionar Plano
        </a>
      </div>
    </div>
  );
}

export default SponsorshipTier;